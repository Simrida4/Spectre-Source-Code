﻿using System.Windows;
using System.Windows.Controls;

namespace Spectre_V2
{
    public partial class App : Application
    {
        private int tabCount = 2;
        private void CloseBtn_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = (MainWindow)base.MainWindow;
            TabItem removeItem = (TabItem)mainWindow.tabs.SelectedItem;
            mainWindow.tabs.Items.Remove(removeItem);
            tabCount--;
        }

        private void AddBtn_Click(object sender, RoutedEventArgs e)
        {
            WebViewAPI content = new WebViewAPI();
            TabItem newItem = new TabItem
            {
                Header = "Script " + tabCount,
                Content = content,
                Style = (Style)FindResource("TabItem")
            };
            MainWindow mainWindow = (MainWindow)base.MainWindow;
            mainWindow.tabs.Items.Add(newItem);
            tabCount++;
        }
    }
}
