﻿using System;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Animation;
using Newtonsoft.Json;
using EasyExploits;
using Microsoft.Win32;
using Microsoft.Web.WebView2.Wpf;
using Microsoft.Web.WebView2.Core;
using System.Net.Http;

namespace Spectre_V2
{
    public partial class MainWindow : Window
    {
        private int tabCount = 1;
        EasyExploits.Module api = new EasyExploits.Module();
        private Storyboard storyboard = new Storyboard();
        private TimeSpan halfsecond = TimeSpan.FromMilliseconds(500.0);
        private TimeSpan second = TimeSpan.FromMilliseconds(1000.0);
        private string searchthingy = "";
        private int pagenumber = 1;
        private HttpClient httpclientthingy = new HttpClient();

        private IEasingFunction Smooth { get; set; } = new QuarticEase
        {
            EasingMode = EasingMode.EaseInOut
        };

        public MainWindow()
        {
            InitializeComponent();
            getgoodies();

            HomePage.Visibility = Visibility.Collapsed;
            SettingsPage.Visibility = Visibility.Collapsed;
            ScriptBloxPage.Visibility = Visibility.Collapsed;

            FileInfo[] files = new DirectoryInfo("./scripts").GetFiles("*txt");
            foreach (FileInfo fileInfo in files)
            {
                listbox1.Items.Add(fileInfo.Name);
            }
            FileInfo[] files2 = new DirectoryInfo("./scripts").GetFiles("*lua");
            foreach (FileInfo fileInfo2 in files2)
            {
                listbox1.Items.Add(fileInfo2.Name);
            }
        }

        private async void getgoodies()
        {
            try
            {
                Wrap1.Children.Clear();
                HttpResponseMessage response = await httpclientthingy.GetAsync("https://scriptblox.com/api/script/search?q=" + searchthingy);
                HttpContent content = response.Content;
                object dynJson = JsonConvert.DeserializeObject(await content.ReadAsStringAsync());

                foreach (dynamic item in ((dynamic)dynJson).result.scripts)
                {
                    dynamic jsonitem = JsonConvert.DeserializeObject<object>(((object)item).ToString());
                    dynamic script = Convert.ToString(jsonitem.script);
                    dynamic dastitle = Convert.ToString(jsonitem.title);
                    dynamic descthingy = Convert.ToString(jsonitem.slug);
                    dynamic dathingyviews = Convert.ToString(jsonitem.views);
                    dynamic imagethingy = Convert.ToString(jsonitem.game.imageUrl);
                    dynamic key = Convert.ToString(jsonitem.key);

                    Wrap1.Children.Add(new ScriptThingy(imagethingy, script, dastitle, descthingy, dathingyviews, key));

                    await Task.Delay(250);
                }
            }

            catch
            {
                MessageBox.Show("Something went worg");
            }
        }

        public WebViewAPI TabSelecionada2()
        {
            return tabs.SelectedContent as WebViewAPI;
        }

        public void Fade(DependencyObject Object)
        {
            DoubleAnimation doubleAnimation = new DoubleAnimation
            {
                From = 0.0,
                To = 1.0, 
                Duration = new Duration(halfsecond)
            };
            Storyboard.SetTarget(doubleAnimation, Object);
            Storyboard.SetTargetProperty(doubleAnimation, new PropertyPath("Opacity", 1));
            storyboard.Children.Add(doubleAnimation);
            storyboard.Begin();
        }

        public void FadeOut(DependencyObject Object)
        {
            DoubleAnimation doubleAnimation = new DoubleAnimation
            {
                From = 1.0,
                To = 0.0,
                Duration = new Duration(halfsecond)
            };
            Storyboard.SetTarget(doubleAnimation, Object);
            Storyboard.SetTargetProperty(doubleAnimation, new PropertyPath("Opacity", 1));
            storyboard.Children.Add(doubleAnimation);
            storyboard.Begin();
            storyboard.Children.Remove(doubleAnimation);
        }

        public void ObjectShift(DependencyObject Object, Thickness Get, Thickness Set)
        {
            ThicknessAnimation thicknessAnimation = new ThicknessAnimation
            {
                From = Get,
                To = Set,
                Duration = second,
                EasingFunction = Smooth
            };
            Storyboard.SetTarget(thicknessAnimation, Object);
            Storyboard.SetTargetProperty(thicknessAnimation, new PropertyPath(FrameworkElement.MarginProperty));
            storyboard.Children.Add(thicknessAnimation);
            storyboard.Begin();
        }


        private async void MainWindowBD_Loaded(object sender, RoutedEventArgs e)
        {
            if (HomePage.Visibility == Visibility.Collapsed)
            {
                await Task.Delay(500);
                Fade(HomePage);
                ObjectShift(HomePage, HomePage.Margin, new Thickness(8, 32, 8, 7));
                HomePage.Visibility = Visibility.Visible;
            }
            else if (HomePage.Visibility == Visibility.Visible)
            {
                await Task.Delay(500);
                FadeOut(HomePage);
                ObjectShift(HomePage, HomePage.Margin, new Thickness(8, 364, 8, -325));
                HomePage.Visibility = Visibility.Collapsed;
            }

            WebViewAPI content = new WebViewAPI();
            TabItem newItem = new TabItem
            {
                Header = "Script " + tabCount,
                Content = content,
                Style = (Style)FindResource("TabItem")
            };
            tabs.Items.Add(newItem);
        }

        private void MainWindowBD_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                DragMove();
            }
        }

        private async void AttachBtn_Click(object sender, RoutedEventArgs e)
        {
            if (EE_API.IsChecked == true)
            {
                api.LaunchExploit();
                await Task.Delay(500);
            }
        }

        private async void ExecuteBtn_Click(object sender, RoutedEventArgs e)
        {
            if (EE_API.IsChecked == true)
            {
                string text = await TabSelecionada2().GetText();
                api.ExecuteScript(text);
            }
        }

        private void ClearBtn_Click(object sender, RoutedEventArgs e)
        {
            TabSelecionada2().SetText("");
        }

        private void OpenBtn_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Txt Files (*.txt)|*.txt|Lua Files (*.lua)|*.lua|All Files (*.*)|*.*";
            if (openFileDialog.ShowDialog() == true)
            {
                string text = File.ReadAllText(openFileDialog.FileName);
                TabSelecionada2().SetText(text);
            }
        }

        private async void SaveBtn_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog dialog = new SaveFileDialog
            {
                Filter = "Txt Files (*.txt)|*.txt|Lua Files (*.lua)|*.lua|All Files (*.*)|*.*"
            };
            if (dialog.ShowDialog() == true)
            {
                File.WriteAllText(contents: await TabSelecionada2().GetText(), path: dialog.FileName);
            }
        }

        private void MinimizeBtn_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void MaximizeBtn_Click(object sender, RoutedEventArgs e)
        {
            if (WindowState != WindowState.Maximized)
                WindowState = WindowState.Maximized;
            else
                WindowState = WindowState.Normal;
        }

        private void CloseBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private async void SettingsBtn_Click(object sender, RoutedEventArgs e)
        {
            if (SettingsPage.Visibility == Visibility.Collapsed)
            {
                await Task.Delay(500);
                Fade(SettingsPage);
                Fade(HomePage);
                Fade(ScriptBloxPage);
                ObjectShift(SettingsPage, SettingsPage.Margin, new Thickness(8, 32, 8, 7));
                ObjectShift(HomePage, HomePage.Margin, new Thickness(8, 364, 8, -325));
                ObjectShift(ScriptBloxPage, ScriptBloxPage.Margin, new Thickness(711, 32, -695, 7));
                await Task.Delay(500);
                HomePage.Visibility = Visibility.Collapsed;
                SettingsPage.Visibility = Visibility.Visible;
                ScriptBloxPage.Visibility = Visibility.Collapsed;
            }
            else if (SettingsPage.Visibility == Visibility.Visible)
            {
                await Task.Delay(500);
                FadeOut(SettingsPage);
                FadeOut(HomePage);
                FadeOut(ScriptBloxPage);
                ObjectShift(SettingsPage, SettingsPage.Margin, new Thickness(711, 32, -695, 7));
                ObjectShift(HomePage, HomePage.Margin, new Thickness(8, 32, 8, 7));
                ObjectShift(ScriptBloxPage, ScriptBloxPage.Margin, new Thickness(711, 32, -695, 7));
                await Task.Delay(500);
                SettingsPage.Visibility = Visibility.Collapsed;
                ScriptBloxPage.Visibility = Visibility.Collapsed;
                HomePage.Visibility = Visibility.Visible;
            }
        }

        private void TOPMOST_Checked(object sender, RoutedEventArgs e)
        {
            Topmost = true;
        }

        private void TOPMOST_Unchecked(object sender, RoutedEventArgs e)
        {
            Topmost = false;
        }

        private void EE_API_Checked(object sender, RoutedEventArgs e) { }  
        private void EE_API_Unchecked(object sender, RoutedEventArgs e) { }
        private void Krnl_API_Unchecked(object sender, RoutedEventArgs e) { }
        private void Krnl_API_Checked(object sender, RoutedEventArgs e) { }

        private void Image_MouseDown(object sender, MouseButtonEventArgs e)
        {
            System.Diagnostics.Process.Start("https://discord.gg/e5kyhmRj4e");
        }

        private void listbox1_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            string text = File.ReadAllText("./scripts/" + listbox1.SelectedItem);
            TabSelecionada2().SetText(text);
        }

        private async void ScriptBlox_Click(object sender, RoutedEventArgs e)
        {
            if (ScriptBloxPage.Visibility == Visibility.Collapsed) // 8,32,8,8
            {
                await Task.Delay(500);
                Fade(ScriptBloxPage);
                Fade(HomePage);
                Fade(SettingsPage);
                ObjectShift(ScriptBloxPage, ScriptBloxPage.Margin, new Thickness(8, 32, 8, 7));
                ObjectShift(HomePage, HomePage.Margin, new Thickness(8, 364, 8, -325));
                ObjectShift(SettingsPage, SettingsPage.Margin, new Thickness(711, 32, -695, 7));
                await Task.Delay(500);
                HomePage.Visibility = Visibility.Collapsed;
                SettingsPage.Visibility = Visibility.Collapsed;
                ScriptBloxPage.Visibility = Visibility.Visible;
            }
        }

        private void SearchBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Return) 
            { 
                searchthingy = SearchBox.Text;
                getgoodies();
            }
        }

        private async void ScriptBloxCloseBtn_Click(object sender, RoutedEventArgs e)
        {
            if (ScriptBloxPage.Visibility == Visibility.Visible)
            {
                await Task.Delay(500);
                FadeOut(ScriptBloxPage);
                FadeOut(HomePage);
                FadeOut(SettingsPage);
                ObjectShift(ScriptBloxPage, ScriptBloxPage.Margin, new Thickness(8, -319, 8, 359));
                ObjectShift(HomePage, HomePage.Margin, new Thickness(8, 32, 8, 7));
                ObjectShift(SettingsPage, SettingsPage.Margin, new Thickness(711, 32, -695, 7));
                await Task.Delay(500);
                ScriptBloxPage.Visibility = Visibility.Collapsed;
                SettingsPage.Visibility = Visibility.Collapsed;
                HomePage.Visibility = Visibility.Visible;
            }
        }
    }
}
