﻿using System;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using EasyExploits;

namespace Spectre_V2
{
    public partial class ScriptThingy : UserControl
    {
        EasyExploits.Module module = new EasyExploits.Module();
        public ScriptThingy(string image, string script, string title, string desc, string views, string key)
        {
            InitializeComponent();
            ScriptThingy Script = this;
            Description.Text = desc;
            Title.Content = title;
            ScriptViews.Text = views;
            ScriptKey.Text = key;

            ExecuteScript.Click += delegate
            {
                Script.module.ExecuteScript(script);
            };

            try
            {
                ImageBrush brush = new ImageBrush();
                brush.ImageSource = new BitmapImage(new Uri(image));
                ImageThingy.Background = brush;
            }

            catch 
            {
                try
                {
                    ImageBrush brush = new ImageBrush();
                    brush.ImageSource = new BitmapImage(new Uri("https://scriptblox.com" + image));
                    ImageThingy.Background = brush;
                }

                catch 
                {
                    try 
                    {
                        ImageBrush brush = new ImageBrush();
                        brush.ImageSource = new BitmapImage(new Uri("https://scriptblox.com/images/no-script.webp" + image));
                        ImageThingy.Background = brush;
                    }

                    catch { }
                }
            }
        }
    }
}
