using System;
using System.Drawing;
using System.IO;
using System.Threading.Tasks;
using System.Web;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.Wpf;
using Spectre;

public class WebViewAPI : WebView2
{
	private string ToSetText;

	private string LatestRecievedText;

	public bool isDOMLoaded { get; set; } = false;


	public event EventHandler EditorReady;

	public WebViewAPI(string Text = "")
	{
		base.Source = new Uri(Directory.GetCurrentDirectory() + "\\bin\\Monaco\\Monaco.html");
		base.DefaultBackgroundColor = Color.FromArgb(255, 25, 25, 25);
		base.CoreWebView2InitializationCompleted += WebViewAPI_CoreWebView2InitializationCompleted;
		ToSetText = Text;
	}

	protected virtual void OnEditorReady()
	{
		this.EditorReady?.Invoke(this, new EventArgs());
	}

	private void WebViewAPI_CoreWebView2InitializationCompleted(object sender, CoreWebView2InitializationCompletedEventArgs e)
	{
		base.CoreWebView2.DOMContentLoaded += CoreWebView2_DOMContentLoaded;
		base.CoreWebView2.WebMessageReceived += CoreWebView2_WebMessageReceived;
		base.CoreWebView2.Settings.AreDefaultContextMenusEnabled = false;
		base.CoreWebView2.Settings.AreDevToolsEnabled = false;
	}

	private void CoreWebView2_WebMessageReceived(object sender, CoreWebView2WebMessageReceivedEventArgs e)
	{
		LatestRecievedText = e.TryGetWebMessageAsString();
	}

	private async void CoreWebView2_DOMContentLoaded(object sender, CoreWebView2DOMContentLoadedEventArgs e)
	{
		await Task.Delay(1000);
		isDOMLoaded = true;
		SetText(ToSetText);
		OnEditorReady();
	}

	public async Task<string> GetText()
	{
		if (isDOMLoaded)
		{
			await ExecuteScriptAsync("window.chrome.webview.postMessage(editor.getValue())");
			await Task.Delay(200);
			return LatestRecievedText.ToString();
		}
		return string.Empty;
	}

	public async void SetText(string text)
	{
		if (isDOMLoaded)
		{
			await base.CoreWebView2.ExecuteScriptAsync("SetText(\"" + HttpUtility.JavaScriptStringEncode(text) + "\")");
		}
	}

	public void AddIntellisense(string label, Types type, string description, string insert)
	{
		if (isDOMLoaded)
		{
			string text = type.ToString();
			if (type == Types.None)
			{
				text = "";
			}
			ExecuteScriptAsync("AddIntellisense(" + label + ", " + text + ", " + description + ", " + insert + ");");
		}
	}

	public void Refresh()
	{
		if (isDOMLoaded)
		{
			ExecuteScriptAsync("Refresh();");
		}
	}
}
