using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media.Animation;
using Microsoft.Win32;
using Spectre;
using WeAreDevs_API;

public class MainWindow : Window, IComponentConnector
{
	private ExploitAPI Spectre = new ExploitAPI();
	private Storyboard storyboard = new Storyboard();
	private TimeSpan halfsecond = TimeSpan.FromMilliseconds(500.0);
	private TimeSpan second = TimeSpan.FromMilliseconds(1000.0);
	private int tabCount = 1;

	private IEasingFunction Smooth { get; set; } = new QuarticEase
	{
		EasingMode = EasingMode.EaseInOut
	};


	public MainWindow()
	{
		InitializeComponent();
		ButtonsFrame.Visibility = Visibility.Collapsed;
		listbox1.Visibility = Visibility.Collapsed;
		SettingsMenu.Visibility = Visibility.Collapsed;
		FileInfo[] files = new DirectoryInfo("./scripts").GetFiles("*txt");
		foreach (FileInfo fileInfo in files)
		{
			listbox1.Items.Add(fileInfo.Name);
		}
		FileInfo[] files2 = new DirectoryInfo("./scripts").GetFiles("*lua");
		foreach (FileInfo fileInfo2 in files2)
		{
			listbox1.Items.Add(fileInfo2.Name);
		}
	}

	public WebViewAPI TabSelecionada2()
	{
		return tabs.SelectedContent as WebViewAPI;
	}

	public void Fade(DependencyObject Object)
	{
		DoubleAnimation doubleAnimation = new DoubleAnimation
		{
			From = 0.0,
			To = 1.0,
			Duration = new Duration(halfsecond)
		};
		Storyboard.SetTarget(doubleAnimation, Object);
		Storyboard.SetTargetProperty(doubleAnimation, new PropertyPath("Opacity", 1));
		storyboard.Children.Add(doubleAnimation);
		storyboard.Begin();
	}

	public void FadeOut(DependencyObject Object)
	{
		DoubleAnimation doubleAnimation = new DoubleAnimation
		{
			From = 1.0,
			To = 0.0,
			Duration = new Duration(halfsecond)
		};
		Storyboard.SetTarget(doubleAnimation, Object);
		Storyboard.SetTargetProperty(doubleAnimation, new PropertyPath("Opacity", 1));
		storyboard.Children.Add(doubleAnimation);
		storyboard.Begin();
		storyboard.Children.Remove(doubleAnimation);
	}

	public void ObjectShift(DependencyObject Object, Thickness Get, Thickness Set)
	{
		ThicknessAnimation thicknessAnimation = new ThicknessAnimation
		{
			From = Get,
			To = Set,
			Duration = second,
			EasingFunction = Smooth
		};
		Storyboard.SetTarget(thicknessAnimation, Object);
		Storyboard.SetTargetProperty(thicknessAnimation, new PropertyPath(FrameworkElement.MarginProperty));
		storyboard.Children.Add(thicknessAnimation);
		storyboard.Begin();
	}

	private async void ShowButtons_Click(object sender, RoutedEventArgs e)
	{
		if (ButtonsFrame.Visibility == Visibility.Collapsed)
		{
			await Task.Delay(500);
			Fade(ButtonsFrame);
			ObjectShift(ButtonsFrame, ButtonsFrame.Margin, new Thickness(321.0, 311.0, 45.0, 17.0));
			ButtonsFrame.Visibility = Visibility.Visible;
		}
		else if (ButtonsFrame.Visibility == Visibility.Visible)
		{
			await Task.Delay(500);
			FadeOut(ButtonsFrame);
			FadeOut(tabs);
			ObjectShift(ButtonsFrame, ButtonsFrame.Margin, new Thickness(548.0, 311.0, -182.0, 17.0));
			ObjectShift(tabs, tabs.Margin, new Thickness(20.0, 40.0, 19.0, 44.0));
			await Task.Delay(600);
			ButtonsFrame.Visibility = Visibility.Collapsed;
		}
	}

	private void DragMove_MouseDown(object sender, MouseButtonEventArgs e)
	{
		if (e.LeftButton == MouseButtonState.Pressed)
		{
			DragMove();
		}
	}

	private async void ScriptShow_Click(object sender, RoutedEventArgs e)
	{
		if (listbox1.Visibility == Visibility.Collapsed)
		{
			await Task.Delay(500);
			Fade(tabs);
			Fade(listbox1);
			Fade(ButtonsFrame);
			ObjectShift(tabs, tabs.Margin, new Thickness(20.0, 40.0, 155.0, 44.0));
			ObjectShift(listbox1, listbox1.Margin, new Thickness(390.0, 41.0, 19.0, 42.0));
			ObjectShift(ButtonsFrame, ButtonsFrame.Margin, new Thickness(321.0, 311.0, 45.0, 17.0));
			listbox1.Visibility = Visibility.Visible;
		}
		else if (listbox1.Visibility == Visibility.Visible)
		{
			await Task.Delay(500);
			FadeOut(tabs);
			FadeOut(listbox1);
			ObjectShift(tabs, tabs.Margin, new Thickness(20.0, 40.0, 19.0, 44.0));
			ObjectShift(listbox1, listbox1.Margin, new Thickness(390.0, 360.0, 19.0, -277.0));
			await Task.Delay(600);
			listbox1.Visibility = Visibility.Collapsed;
		}
	}

	private void Grid_Loaded(object sender, RoutedEventArgs e)
	{
		WebViewAPI content = new WebViewAPI();
		TabItem newItem = new TabItem
		{
			Header = "Script " + tabCount,
			Content = content,
			Style = (Style)FindResource("TabItem")
		};
		tabs.Items.Add(newItem);
	}

	private void Scripts_SelectionChanged(object sender, SelectionChangedEventArgs e)
	{
		string text = File.ReadAllText("./scripts/" + listbox1.SelectedItem);
		TabSelecionada2().SetText(text);
	}

	private async void Execute_Click(object sender, RoutedEventArgs e)
	{
		string text = await TabSelecionada2().GetText();
		Spectre.SendLuaScript(text);
		Spectre.SendLuaCScript(text);
	}

	private void Clear_Click(object sender, RoutedEventArgs e)
	{
		TabSelecionada2().SetText("");
	}

	private void OpenFile_Click(object sender, RoutedEventArgs e)
	{
		OpenFileDialog openFileDialog = new OpenFileDialog();
		openFileDialog.Filter = "Txt Files (*.txt)|*.txt|Lua Files (*.lua)|*.lua|All Files (*.*)|*.*";
		if (openFileDialog.ShowDialog() == true)
		{
			string text = File.ReadAllText(openFileDialog.FileName);
			TabSelecionada2().SetText(text);
		}
	}

	private async void SaveFile_Click(object sender, RoutedEventArgs e)
	{
		SaveFileDialog dialog = new SaveFileDialog
		{
			Filter = "Txt Files (*.txt)|*.txt|Lua Files (*.lua)|*.lua|All Files (*.*)|*.*"
		};
		if (dialog.ShowDialog() == true)
		{
			File.WriteAllText(contents: await TabSelecionada2().GetText(), path: dialog.FileName);
		}
	}

	private void Attach_Click(object sender, RoutedEventArgs e)
	{
		Spectre.LaunchExploit();
	}

	private void Close_Click(object sender, RoutedEventArgs e)
	{
		Close();
	}

	private void Minimize_Click(object sender, RoutedEventArgs e)
	{
		base.WindowState = WindowState.Minimized;
	}

	private void TopMost_Unchecked(object sender, RoutedEventArgs e)
	{
		base.Topmost = false;
	}

	private void TopMost_Checked(object sender, RoutedEventArgs e)
	{
		base.Topmost = true;
	}

	private async void Settings_Click(object sender, RoutedEventArgs e)
	{
		if (SettingsMenu.Visibility == Visibility.Collapsed)
		{
			await Task.Delay(500);
			Fade(tabs);
			Fade(SettingsMenu);
			Fade(ButtonsFrame);
			ObjectShift(tabs, tabs.Margin, new Thickness(-535.0, 40.0, 574.0, 44.0));
			ObjectShift(SettingsMenu, SettingsMenu.Margin, new Thickness(20.0, 40.0, 16.0, 44.0));
			ObjectShift(ButtonsFrame, ButtonsFrame.Margin, new Thickness(321.0, 311.0, 45.0, 17.0));
			SettingsMenu.Visibility = Visibility.Visible;
		}
		else if (SettingsMenu.Visibility == Visibility.Visible)
		{
			await Task.Delay(500);
			FadeOut(tabs);
			Fade(SettingsMenu);
			ObjectShift(tabs, tabs.Margin, new Thickness(20.0, 40.0, 19.0, 44.0));
			ObjectShift(SettingsMenu, SettingsMenu.Margin, new Thickness(20.0, -273.0, 16.0, 357.0));
			await Task.Delay(600);
			SettingsMenu.Visibility = Visibility.Collapsed;
		}
	}

	private void Refresh_Click(object sender, RoutedEventArgs e)
	{
		listbox1.Items.Clear();
		Functions.PopulateListBox(listbox1, "./scripts", "*.txt");
		Functions.PopulateListBox(listbox1, "./scripts", "*.lua");
	}

	private void FPSUnlocker_Checked(object sender, RoutedEventArgs e)
	{
		Process.Start(".\\bin\\rbxfpsunlocker");
	}

	private void FPSUnlocker_Unchecked(object sender, RoutedEventArgs e)
	{
	}

	private void MoreROBLOX_Unchecked(object sender, RoutedEventArgs e)
	{
	}

	private void MoreROBLOX_Checked(object sender, RoutedEventArgs e)
	{
		Process.Start(".\\bin\\Multiple_ROBLOX");
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
	public void InitializeComponent()
	{
		if (!_contentLoaded)
		{
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/Spectre;component/mainwindow.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	void IComponentConnector.Connect(int connectionId, object target)
	{
		switch (connectionId)
		{
		case 1:
			((MainWindow)target).MouseDown += DragMove_MouseDown;
			break;
		case 2:
			((Grid)target).Loaded += Grid_Loaded;
			break;
		case 3:
			((Button)target).Click += Close_Click;
			break;
		case 4:
			((Button)target).Click += Minimize_Click;
			break;
		case 5:
			Buttons = (Border)target;
			break;
		case 6:
			((Button)target).Click += ShowButtons_Click;
			break;
		case 7:
			ButtonsFrame = (Border)target;
			break;
		case 8:
			((Button)target).Click += Execute_Click;
			break;
		case 9:
			((Button)target).Click += Clear_Click;
			break;
		case 10:
			((Button)target).Click += OpenFile_Click;
			break;
		case 11:
			((Button)target).Click += SaveFile_Click;
			break;
		case 12:
			((Button)target).Click += ScriptShow_Click;
			break;
		case 13:
			((Button)target).Click += Settings_Click;
			break;
		case 14:
			((Button)target).Click += Attach_Click;
			break;
		case 15:
			listbox1 = (ListBox)target;
			listbox1.SelectionChanged += Scripts_SelectionChanged;
			break;
		case 16:
			tabs = (TabControl)target;
			break;
		case 17:
			SettingsMenu = (Grid)target;
			break;
		case 18:
			((CheckBox)target).Unchecked += TopMost_Unchecked;
			((CheckBox)target).Checked += TopMost_Checked;
			break;
		case 19:
			((CheckBox)target).Checked += FPSUnlocker_Checked;
			((CheckBox)target).Unchecked += FPSUnlocker_Unchecked;
			break;
		case 20:
			((CheckBox)target).Unchecked += MoreROBLOX_Unchecked;
			((CheckBox)target).Checked += MoreROBLOX_Checked;
			break;
		default:
			_contentLoaded = true;
			break;
		}
	}
}
