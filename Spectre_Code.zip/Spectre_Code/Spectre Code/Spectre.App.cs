using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using Spectre;

public class App : Application, IStyleConnector
{
	private int tabCount = 2;

	private void AddBtn_Click(object sender, RoutedEventArgs e)
	{
		WebViewAPI content = new WebViewAPI();
		TabItem newItem = new TabItem
		{
			Header = "Script " + tabCount,
			Content = content,
			Style = (Style)FindResource("TabItem")
		};
		MainWindow mainWindow = (MainWindow)base.MainWindow;
		mainWindow.tabs.Items.Add(newItem);
		tabCount++;
	}

	private void CloseBtn_Click(object sender, RoutedEventArgs e)
	{
		MainWindow mainWindow = (MainWindow)base.MainWindow;
		TabItem removeItem = (TabItem)mainWindow.tabs.SelectedItem;
		mainWindow.tabs.Items.Remove(removeItem);
		tabCount--;
	}
}
